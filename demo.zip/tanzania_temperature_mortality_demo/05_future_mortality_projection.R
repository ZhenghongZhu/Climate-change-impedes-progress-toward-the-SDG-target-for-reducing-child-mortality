# Tanzania child-mortality demo: 05 of 05
# Manuscript sequence:
# historical total U5MR -> historical temperature-unrelated U5MR -> future
# temperature-unrelated U5MR -> future heat/cold U5MR -> future total U5MR.

project_path <- "."
setwd(project_path)
processed_dir <- "data_processed"
output_dir <- "outputs"
dir.create(output_dir, showWarnings = FALSE)

files <- c(
  model = file.path(processed_dir, "tanzania_aggregate_dlnm_model.rds"),
  hist_temp = file.path(processed_dir, "tanzania_historical_daily_exposure.csv"),
  hist_death = file.path(processed_dir,
                         "tanzania_daily_deaths_random_redistribution_example.csv"),
  hist_total = file.path(processed_dir, "tanzania_historical_total_u5mr_demography.csv"),
  baseline_2019 = file.path(processed_dir, "tanzania_total_u5mr_baseline_2019.csv"),
  future_demo = file.path(processed_dir, "tanzania_future_population_births.csv"),
  future_temp = file.path(processed_dir, "tanzania_future_daily_temperature.csv"),
  diagnostics = file.path(output_dir, "model_diagnostics.csv")
)
read_input <- function(name) read.csv(files[name], stringsAsFactors = FALSE)

model_info <- readRDS(files["model"])
hist_temp <- read_input("hist_temp")
hist_death <- read_input("hist_death")
hist_total <- read_input("hist_total")
baseline_2019 <- read_input("baseline_2019")$total_u5mr_per_1000[1]
future_demo <- read_input("future_demo")
future_temp <- read_input("future_temp")
mmt <- read_input("diagnostics")$estimated_mmt_c[1]

# Reduce the DLNM to the overall exposure-response
# dimension and evaluate its spline basis at each future temperature.
rr_at <- function(temp) {
  erf <- model_info$reduced_erf
  basis <- do.call(dlnm::onebasis, c(list(x = temp), erf$argvar))
  basis_mmt <- do.call(dlnm::onebasis, c(list(x = mmt), erf$argvar))
  log_rr <- drop(sweep(basis, 2, basis_mmt, "-") %*% erf$coefficients)
  pmax(1, exp(log_rr))
}

# Returns heat and cold PAFs. Adaptation reduces excess risk (RR - 1), then PAF
# is calculated as (RR - 1) / RR. Weights always sum to one within a year.
annual_paf <- function(temp, rr, weight, adaptation = 0) {
  rr_adapted <- 1 + (rr - 1) * (1 - adaptation)
  paf <- (rr_adapted - 1) / rr_adapted
  weight <- weight / sum(weight)
  c(
    heat_paf = sum(paf[temp >= mmt] * weight[temp >= mmt]),
    cold_paf = sum(paf[temp < mmt] * weight[temp < mmt])
  )
}

# 1. Estimate historical heat, cold and temperature-unrelated U5MR.
hist_temp$date <- as.Date(hist_temp$date)
hist_death$date <- as.Date(hist_death$date)
hist <- merge(hist_temp, hist_death[, c("date", "death_count_randomly_redistributed")],
              by = "date")
hist$year <- as.integer(format(hist$date, "%Y"))
hist$day_of_year <- as.integer(format(hist$date, "%j"))
hist$rr <- rr_at(hist$temp_c)
hist$pdd <- ave(hist$death_count_randomly_redistributed, hist$year,
                FUN = function(x) x / sum(x))

hist_paf <- do.call(rbind, lapply(split(hist, hist$year), function(x) {
  data.frame(year = x$year[1], t(annual_paf(x$temp_c, x$rr, x$pdd)))
}))
hist_components <- merge(hist_total, hist_paf, by = "year", sort = TRUE)
hist_components$heat_related_u5mr_per_1000 <-
  hist_components$total_u5mr_per_1000 * hist_components$heat_paf
hist_components$cold_related_u5mr_per_1000 <-
  hist_components$total_u5mr_per_1000 * hist_components$cold_paf
hist_components$temperature_unrelated_u5mr_per_1000 <- with(
  hist_components,
  total_u5mr_per_1000 - heat_related_u5mr_per_1000 - cold_related_u5mr_per_1000
)
write.csv(hist_components,
          file.path(output_dir, "tanzania_historical_mortality_decomposition.csv"),
          row.names = FALSE)

# 2. Estimate the 1990--2018 annual reduction and extend it to 2100.
ut_1990 <- hist_components$temperature_unrelated_u5mr_per_1000[
  hist_components$year == 1990
]
ut_2018 <- hist_components$temperature_unrelated_u5mr_per_1000[
  hist_components$year == 2018
]
annual_log_change <- log(ut_2018 / ut_1990) / (2018 - 1990)
future_ut <- data.frame(year = sort(unique(future_demo$year)))
future_ut$temperature_unrelated_u5mr_per_1000 <-
  ut_2018 * exp(annual_log_change * (future_ut$year - 2018))

write.csv(data.frame(
  historical_start_year = 1990,
  historical_end_year = 2018,
  temperature_unrelated_u5mr_1990_per_1000 = ut_1990,
  temperature_unrelated_u5mr_2018_per_1000 = ut_2018,
  annual_log_change = annual_log_change,
  annual_reduction_percent = 100 * (1 - exp(annual_log_change)),
  projection_end_year = 2100,
  assumption = "The 1990-2018 annual log change is held constant through 2100."
), file.path(output_dir, "temperature_unrelated_arr_summary.csv"), row.names = FALSE)

# 3. Estimate future heat/cold U5MR from daily PAFs and the fixed 2019 baseline.
# Historical mean PDD by day of year supplies future within-year weights.
pdd_by_day <- aggregate(pdd ~ day_of_year, hist, mean)
future_temp$date <- as.Date(future_temp$date)
future_temp$day_of_year <- as.integer(format(future_temp$date, "%j"))
future_temp <- merge(future_temp, pdd_by_day, by = "day_of_year", all.x = TRUE)
future_temp$rr <- rr_at(future_temp$temp_c)

future_input <- merge(future_demo, future_ut, by = "year")
adaptation <- c("No adaptation" = 0, "10% adaptation" = 0.10,
                "50% adaptation" = 0.50, "90% adaptation" = 0.90)

project_one <- function(i, adaptation_name) {
  x <- future_input[i, ]
  daily <- future_temp[future_temp$scenario == x$scenario &
                         future_temp$year == x$year, ]
  rr_adapted <- 1 + (daily$rr - 1) * (1 - adaptation[adaptation_name])
  daily_af <- 1 - 1 / rr_adapted

  # EDE18-0469 formula: daily attributable number = (1 - 1/RR) * daily deaths.
  baseline_deaths <- x$live_births * baseline_2019 / 1000
  daily_deaths <- baseline_deaths * daily$pdd / sum(daily$pdd)
  attributable_deaths <- daily_af * daily_deaths
  heat_deaths <- sum(attributable_deaths[daily$temp_c >= mmt])
  cold_deaths <- sum(attributable_deaths[daily$temp_c < mmt])
  heat_u5mr <- heat_deaths / x$live_births * 1000
  cold_u5mr <- cold_deaths / x$live_births * 1000
  paf <- c(heat_paf = heat_deaths / baseline_deaths,
           cold_paf = cold_deaths / baseline_deaths)
  unrelated_u5mr <- x$temperature_unrelated_u5mr_per_1000
  total_u5mr <- unrelated_u5mr + heat_u5mr + cold_u5mr

  data.frame(
    site_id = x$site_id, country = x$country, scenario = x$scenario, year = x$year,
    adaptation_label = adaptation_name,
    adaptation_risk_reduction = unname(adaptation[adaptation_name]),
    population_total = x$population_total,
    crude_birth_rate_per_1000 = x$crude_birth_rate_per_1000,
    live_births = x$live_births,
    baseline_2019_total_u5mr_per_1000 = baseline_2019,
    annual_heat_paf = paf["heat_paf"], annual_cold_paf = paf["cold_paf"],
    temperature_unrelated_u5mr_per_1000 = unrelated_u5mr,
    heat_related_u5mr_per_1000 = heat_u5mr,
    cold_related_u5mr_per_1000 = cold_u5mr,
    projected_u5mr_per_1000 = total_u5mr,
    temperature_unrelated_deaths = x$live_births * unrelated_u5mr / 1000,
    heat_related_deaths = heat_deaths,
    cold_related_deaths = cold_deaths,
    total_projected_deaths = x$live_births * total_u5mr / 1000
  )
}

projection <- do.call(rbind, lapply(names(adaptation), function(a) {
  do.call(rbind, lapply(seq_len(nrow(future_input)), project_one,
                        adaptation_name = a))
}))
write.csv(projection, file.path(output_dir, "tanzania_future_u5mr_projection.csv"),
          row.names = FALSE)
write.csv(projection[projection$year == 2090, ],
          file.path(output_dir, "tanzania_projection_summary_2090.csv"),
          row.names = FALSE)

# 4. Plot two adaptation pathways; the grey line is temperature-unrelated U5MR.
plot_data <- projection[projection$adaptation_label %in%
                          c("No adaptation", "90% adaptation"), ]
scenario_colours <- c("SSP1-1.9" = "#4C78A8", "SSP2-4.5" = "#59A14F",
                      "SSP3-7.0" = "#F28E2B", "SSP5-8.5" = "#C44E52")
p <- ggplot2::ggplot(
  plot_data,
  ggplot2::aes(year, projected_u5mr_per_1000, colour = scenario,
               linetype = adaptation_label)
) +
  ggplot2::geom_line(linewidth = 0.8) +
  ggplot2::geom_line(
    data = future_ut,
    ggplot2::aes(year, temperature_unrelated_u5mr_per_1000),
    inherit.aes = FALSE, colour = "grey35", linetype = "dotdash", linewidth = 0.9
  ) +
  ggplot2::geom_hline(yintercept = 25, colour = "grey60", linetype = "dotted") +
  ggplot2::scale_colour_manual(values = scenario_colours) +
  ggplot2::labs(
    title = "Synthetic Tanzania projections following the manuscript workflow",
    x = "Year", y = "Projected U5MR per 1,000 live births",
    colour = "Climate scenario", linetype = "Adaptation"
  ) +
  ggplot2::theme_classic(base_size = 11)
grDevices::png(file.path(output_dir, "future_u5mr_projections.png"),
               width = 1620, height = 990, res = 180)
print(p)
grDevices::dev.off()
