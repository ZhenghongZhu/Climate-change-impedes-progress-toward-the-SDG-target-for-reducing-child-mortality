# Tanzania child-mortality demo: 04 of 05
#
# Purpose: create synthetic daily future temperatures and annual population and
# birth inputs for four SSP-style scenarios. Temperature-unrelated U5MR is not an
# input here: script 05 estimates it historically and projects it to 2100, as in
# the manuscript. These are illustrative inputs, not real ISIMIP or UN data.

# Current demo location. Change this one line only if you move the folder.
project_path <- "."
setwd(project_path)
project_dir <- "."
processed_dir <- file.path(project_dir, "data_processed")
output_dir <- file.path(project_dir, "outputs")
dir.create(processed_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)
historical_demography <- read.csv(
  file.path(processed_dir, "tanzania_historical_total_u5mr_demography.csv"),
  stringsAsFactors = FALSE
)
last_historical <- historical_demography[
  historical_demography$year == max(historical_demography$year),
]

scenario_parameters <- data.frame(
  scenario = c("SSP1-1.9", "SSP2-4.5", "SSP3-7.0", "SSP5-8.5"),
  warming_by_2100_c = c(1.8, 2.8, 4.1, 5.4),
  annual_population_growth = c(0.006, 0.009, 0.013, 0.008),
  annual_birth_rate_change = c(-0.012, -0.009, -0.005, -0.007),
  stringsAsFactors = FALSE
)
write.csv(scenario_parameters,
          file.path(processed_dir, "future_scenario_parameters.csv"),
          row.names = FALSE)

future_dates <- seq.Date(as.Date("2020-01-01"), as.Date("2100-12-31"), by = "day")
year <- as.integer(format(future_dates, "%Y"))
day_of_year <- as.integer(format(future_dates, "%j"))
progress <- (year - 2020) / (2100 - 2020)

future_temperature_list <- vector("list", nrow(scenario_parameters))
future_demography_list <- vector("list", nrow(scenario_parameters))

for (i in seq_len(nrow(scenario_parameters))) {
  parameters <- scenario_parameters[i, ]
  set.seed(14062040 + i)

  # Warming accelerates slightly with time. Daily weather variability is retained
  # so annual PAFs can include both heat and cold days relative to the MMT.
  warming <- 0.65 + parameters$warming_by_2100_c * progress^1.20
  daily_temperature <- 25.5 +
    3.6 * sin(2 * pi * (day_of_year - 35) / 365.25) +
    warming +
    rnorm(length(future_dates), mean = 0, sd = 1.25)

  future_temperature_list[[i]] <- data.frame(
    site_id = "TZ_DEMO",
    country = "Tanzania",
    scenario = parameters$scenario,
    date = format(future_dates, "%Y-%m-%d"),
    year = year,
    month = as.integer(format(future_dates, "%m")),
    day_of_year = day_of_year,
    temp_c = round(daily_temperature, 3),
    stringsAsFactors = FALSE
  )

  future_years <- 2020:2100
  years_since_2018 <- future_years - 2018
  population_total <- last_historical$population_total *
    exp(parameters$annual_population_growth * years_since_2018)
  crude_birth_rate <- last_historical$crude_birth_rate_per_1000 *
    exp(parameters$annual_birth_rate_change * years_since_2018)
  live_births <- population_total * crude_birth_rate / 1000

  future_demography_list[[i]] <- data.frame(
    site_id = "TZ_DEMO",
    country = "Tanzania",
    scenario = parameters$scenario,
    year = future_years,
    population_total = round(population_total),
    crude_birth_rate_per_1000 = round(crude_birth_rate, 3),
    live_births = round(live_births),
    stringsAsFactors = FALSE
  )
}

future_temperature <- do.call(rbind, future_temperature_list)
future_demography <- do.call(rbind, future_demography_list)
write.csv(future_temperature,
          file.path(processed_dir, "tanzania_future_daily_temperature.csv"),
          row.names = FALSE)
write.csv(future_demography,
          file.path(processed_dir, "tanzania_future_population_births.csv"),
          row.names = FALSE)

annual_temperature <- aggregate(temp_c ~ scenario + year, data = future_temperature, FUN = mean)
scenario_colours <- c("SSP1-1.9" = "#4C78A8", "SSP2-4.5" = "#59A14F",
                      "SSP3-7.0" = "#F28E2B", "SSP5-8.5" = "#C44E52")
p <- ggplot2::ggplot(annual_temperature,
                     ggplot2::aes(year, temp_c, colour = scenario)) +
  ggplot2::geom_line(linewidth = 0.9) +
  ggplot2::scale_colour_manual(values = scenario_colours) +
  ggplot2::labs(title = "Synthetic future temperature scenarios for Tanzania",
                x = "Year", y = "Mean daily temperature (degrees C)",
                colour = "Climate scenario") +
  ggplot2::theme_classic(base_size = 11)
grDevices::png(file.path(output_dir, "future_temperature_scenarios.png"),
               width = 1530, height = 900, res = 180)
print(p)
grDevices::dev.off()
