# Tanzania child-mortality demo: 03 of 05
#
# Purpose: estimate a distributed lag non-linear temperature--mortality
# association from monthly deaths and daily exposures. This follows the manuscript
# approach for date-heaped deaths: monthly deaths remain the response and daily
# exposures enter a monthly aggregate likelihood. It is a standalone adaptation
# of the fit_aggregate() logic in the supplied Basagana and Ballester code,
# so it does not depend on a machine-specific source path.
#

# Current demo location. Change this one line only if you move the folder.
project_path <- "."
setwd(project_path)
project_dir <- "."
processed_dir <- file.path(project_dir, "data_processed")
output_dir <- file.path(project_dir, "outputs")
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)

exposure_file <- file.path(processed_dir, "tanzania_historical_daily_exposure.csv")
mortality_file <- file.path(processed_dir, "tanzania_monthly_deaths_for_aggregate_model.csv")

# Monthly aggregate Poisson likelihood:
#   Y_m ~ Poisson(sum_d exp(X_dm beta))
# where Y_m is the monthly death count and X_dm contains daily exposures and
# covariates. Random daily allocation is used only to obtain starting values,
# following the aggregate-data approach; observed day 15 counts are not modelled.
fit_monthly_aggregate_dlnm <- function(monthly_counts, daily_data, model_formula) {
  design_full <- stats::model.matrix(
    stats::delete.response(stats::terms(model_formula)), data = daily_data
  )
  # crossbasis() removes its leading rows without complete lag histories. Keep
  # the corresponding daily rows before checking whether a calendar month is
  # complete for aggregate modelling.
  design_rows <- as.integer(rownames(design_full))
  design_data <- daily_data[design_rows, , drop = FALSE]
  complete_rows <- stats::complete.cases(design_full)
  available_per_month <- table(daily_data$ymonth)
  retained_per_month <- table(design_data$ymonth[complete_rows])
  complete_months <- as.integer(names(retained_per_month)[
    retained_per_month == available_per_month[names(retained_per_month)]
  ])

  keep <- complete_rows & design_data$ymonth %in% complete_months
  X <- design_full[keep, , drop = FALSE]
  period_values <- design_data$ymonth[keep]
  periods <- sort(unique(period_values))
  group <- match(period_values, periods)
  y <- monthly_counts$death[match(periods, monthly_counts$ymonth)]

  # Random redistribution used only for a stable initial parameter vector.
  set.seed(14062030)
  y_start <- numeric(nrow(X))
  for (m in seq_along(periods)) {
    rows <- which(group == m)
    y_start[rows] <- as.vector(rmultinom(
      1L, size = y[m], prob = rep(1 / length(rows), length(rows))
    ))
  }
  initial_fit <- suppressWarnings(stats::glm.fit(
    x = X, y = y_start, family = stats::quasipoisson()
  ))
  initial_beta <- initial_fit$coefficients
  initial_beta[is.na(initial_beta)] <- 0
  initial_beta <- pmax(pmin(initial_beta, 5), -5)

  aggregate_loglik <- function(beta) {
    linear_predictor <- pmax(pmin(drop(X %*% beta), 20), -20)
    expected_daily <- exp(linear_predictor)
    expected_monthly <- as.numeric(rowsum(expected_daily, group, reorder = FALSE))
    sum(y * log(expected_monthly) - expected_monthly)
  }

  aggregate_gradient <- function(beta) {
    linear_predictor <- pmax(pmin(drop(X %*% beta), 20), -20)
    expected_daily <- exp(linear_predictor)
    expected_monthly <- as.numeric(rowsum(expected_daily, group, reorder = FALSE))
    score_weight <- expected_daily * (y[group] / expected_monthly[group] - 1)
    drop(crossprod(X, score_weight))
  }

  fit <- stats::optim(
    par = initial_beta,
    fn = function(beta) -aggregate_loglik(beta),
    gr = function(beta) -aggregate_gradient(beta),
    method = "BFGS",
    hessian = TRUE,
    control = list(maxit = 3000, reltol = 1e-10)
  )
  covariance <- solve(fit$hessian)
  colnames(covariance) <- rownames(covariance) <- colnames(X)

  list(
    coefficients = stats::setNames(fit$par, colnames(X)),
    vcov = covariance,
    convergence = fit$convergence,
    log_likelihood = -fit$value,
    retained_months = periods,
    retained_days = nrow(X),
    initial_allocation = "Random allocation for initial values only"
  )
}

exposure <- read.csv(exposure_file, stringsAsFactors = FALSE)
monthly_deaths <- read.csv(mortality_file, stringsAsFactors = FALSE)
exposure$date <- as.Date(exposure$date)

# DLNM specification: temperature lags 0--30 days, natural splines for the
# exposure--response and lag dimensions, plus the calendar and humidity controls
# used in the manuscript's under-five mortality model.
max_lag <- 30
var_knots <- unname(quantile(exposure$temp_c, probs = c(0.10, 0.75), na.rm = TRUE))
boundary_knots <- range(exposure$temp_c, na.rm = TRUE)
lag_knots <- dlnm::logknots(max_lag, 2)
argvar <- list(fun = "ns", knots = var_knots, Boundary.knots = boundary_knots)
cross_basis <- dlnm::crossbasis(
  exposure$temp_c,
  lag = c(0, max_lag),
  argvar = argvar,
  arglag = list(fun = "ns", knots = lag_knots)
)

model_data <- exposure
model_data$death <- NA_real_
model_formula <- death ~
  splines::ns(month, df = 4) +
  splines::ns(year, df = 2) +
  splines::ns(rh_percent, df = 2) +
  cross_basis
aggregate_model <- fit_monthly_aggregate_dlnm(
  monthly_counts = monthly_deaths,
  daily_data = model_data,
  model_formula = model_formula
)

# model.matrix() prefixes cross-basis column names with the object name in the
# formula (cross_basis), whereas colnames(cross_basis) itself does not.
cross_basis_names <- grep("^cross_basis", names(aggregate_model$coefficients), value = TRUE)
beta_cross_basis <- aggregate_model$coefficients[cross_basis_names]
vcov_cross_basis <- aggregate_model$vcov[cross_basis_names, cross_basis_names, drop = FALSE]

# Derive the minimum-mortality temperature (MMT) and the cumulative association.
at_temperature <- sort(unique(round(
  quantile(exposure$temp_c, probs = seq(0.01, 0.99, by = 0.01)), 3
)))
initial_prediction <- dlnm::crosspred(
  cross_basis, coef = beta_cross_basis, vcov = vcov_cross_basis,
  cen = median(exposure$temp_c), at = at_temperature, model.link = "log"
)
mmt <- initial_prediction$predvar[which.min(initial_prediction$allRRfit)]
prediction <- dlnm::crosspred(
  cross_basis, coef = beta_cross_basis, vcov = vcov_cross_basis,
  cen = mmt, at = at_temperature, model.link = "log"
)
reduced_erf <- dlnm::crossreduce(
  cross_basis, coef = beta_cross_basis, vcov = vcov_cross_basis,
  cen = mmt, model.link = "log"
)

response_curve <- data.frame(
  temperature_c = prediction$predvar,
  rr = prediction$allRRfit,
  rr_low = prediction$allRRlow,
  rr_high = prediction$allRRhigh,
  stringsAsFactors = FALSE
)
write.csv(response_curve,
          file.path(processed_dir, "tanzania_temperature_response_curve.csv"),
          row.names = FALSE)

# Wald test of the full temperature cross-basis. Together with elevated risks at
# both tails relative to the estimated MMT, this documents the intended
# significant U-shaped association in the synthetic data.
wald_statistic <- as.numeric(t(beta_cross_basis) %*% solve(vcov_cross_basis, beta_cross_basis))
wald_df <- length(beta_cross_basis)
wald_p <- stats::pchisq(wald_statistic, df = wald_df, lower.tail = FALSE)

nearest_row <- function(x) which.min(abs(response_curve$temperature_c - x))
cold_temperature <- unname(quantile(exposure$temp_c, 0.10))
heat_temperature <- unname(quantile(exposure$temp_c, 0.90))
cold_row <- nearest_row(cold_temperature)
heat_row <- nearest_row(heat_temperature)

model_diagnostics <- data.frame(
  model = "Monthly aggregate DLNM with daily temperature exposures",
  site_id = "TZ_DEMO",
  maximum_lag_days = max_lag,
  retained_months = length(aggregate_model$retained_months),
  estimated_mmt_c = mmt,
  temperature_crossbasis_wald_p = wald_p,
  cold_reference_temperature_c = response_curve$temperature_c[cold_row],
  cold_rr = response_curve$rr[cold_row],
  cold_rr_low = response_curve$rr_low[cold_row],
  cold_rr_high = response_curve$rr_high[cold_row],
  heat_reference_temperature_c = response_curve$temperature_c[heat_row],
  heat_rr = response_curve$rr[heat_row],
  heat_rr_low = response_curve$rr_low[heat_row],
  heat_rr_high = response_curve$rr_high[heat_row],
  stringsAsFactors = FALSE
)
write.csv(model_diagnostics,
          file.path(output_dir, "model_diagnostics.csv"),
          row.names = FALSE)

saveRDS(
  list(
    aggregate_model = aggregate_model,
    mmt_c = mmt,
    maximum_lag_days = max_lag,
    reduced_erf = list(
      coefficients = stats::coef(reduced_erf),
      vcov = stats::vcov(reduced_erf),
      argvar = argvar
    ),
    var_knots = var_knots,
    lag_knots = lag_knots,
    boundary_knots = boundary_knots,
    model_formula = model_formula
  ),
  file.path(processed_dir, "tanzania_aggregate_dlnm_model.rds")
)

p <- ggplot2::ggplot(response_curve, ggplot2::aes(temperature_c, rr)) +
  ggplot2::geom_ribbon(ggplot2::aes(ymin = rr_low, ymax = rr_high),
                       fill = "#4C78A8", alpha = 0.22) +
  ggplot2::geom_line(colour = "#1F4E79", linewidth = 1) +
  ggplot2::geom_hline(yintercept = 1, colour = "grey40", linetype = "dashed") +
  ggplot2::geom_vline(xintercept = mmt, colour = "#C44E52", linetype = "dashed") +
  ggplot2::labs(title = "Synthetic Tanzania U-shaped temperature--mortality association",
                subtitle = paste0("Estimated MMT = ", round(mmt, 1), " degrees C"),
                x = "Daily mean temperature (degrees C)",
                y = "Cumulative relative risk") +
  ggplot2::theme_classic(base_size = 11)
grDevices::png(file.path(output_dir, "temperature_mortality_exposure_response.png"),
               width = 1530, height = 900, res = 180)
print(p)
grDevices::dev.off()

