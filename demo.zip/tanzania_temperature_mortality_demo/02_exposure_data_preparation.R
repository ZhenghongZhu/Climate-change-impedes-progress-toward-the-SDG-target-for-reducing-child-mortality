# Tanzania child-mortality demo: 02 of 05
#
# Purpose: prepare daily temperature and relative-humidity exposures for the
# synthetic Tanzania site. Run after 01_mortality_data_preparation.R.


# Current demo location. Change this one line only if you move the folder.
project_path <- "."
setwd(project_path)
project_dir <- "."
processed_dir <- file.path(project_dir, "data_processed")
output_dir <- file.path(project_dir, "outputs")
dir.create(processed_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)

# This function intentionally matches script 01 exactly.
simulate_historical_temperature <- function(dates) {
  set.seed(14062026)
  day_of_year <- as.integer(format(dates, "%j"))
  year_index <- as.integer(format(dates, "%Y")) - min(as.integer(format(dates, "%Y")))
  25.5 +
    3.6 * sin(2 * pi * (day_of_year - 35) / 365.25) +
    0.035 * year_index +
    rnorm(length(dates), mean = 0, sd = 1.25)
}

dates <- seq.Date(as.Date("1990-01-01"), as.Date("2018-12-31"), by = "day")
temperature <- simulate_historical_temperature(dates)

set.seed(14062027)
relative_humidity <- pmin(100, pmax(20,
  72 - 0.9 * (temperature - 25.5) +
    5 * cos(2 * pi * (as.integer(format(dates, "%j")) + 20) / 365.25) +
    rnorm(length(dates), 0, 4)
))

exposure <- data.frame(
  site_id = "TZ_DEMO",
  country = "Tanzania",
  date = format(dates, "%Y-%m-%d"),
  year = as.integer(format(dates, "%Y")),
  month = as.integer(format(dates, "%m")),
  ymonth = as.integer(format(dates, "%Y%m")),
  day_of_year = as.integer(format(dates, "%j")),
  temp_c = round(temperature, 3),
  rh_percent = round(relative_humidity, 3),
  stringsAsFactors = FALSE
)
write.csv(exposure,
          file.path(processed_dir, "tanzania_historical_daily_exposure.csv"),
          row.names = FALSE)

exposure_summary <- data.frame(
  variable = c("temperature_c", "relative_humidity_percent"),
  minimum = c(min(exposure$temp_c), min(exposure$rh_percent)),
  p10 = c(unname(quantile(exposure$temp_c, 0.10)), unname(quantile(exposure$rh_percent, 0.10))),
  median = c(median(exposure$temp_c), median(exposure$rh_percent)),
  p90 = c(unname(quantile(exposure$temp_c, 0.90)), unname(quantile(exposure$rh_percent, 0.90))),
  maximum = c(max(exposure$temp_c), max(exposure$rh_percent)),
  stringsAsFactors = FALSE
)
write.csv(exposure_summary,
          file.path(output_dir, "historical_exposure_summary.csv"),
          row.names = FALSE)

first_two_years <- exposure$year %in% c(1990, 1991)
plot_data <- exposure[first_two_years, ]
plot_data$date <- as.Date(plot_data$date)
p <- ggplot2::ggplot(plot_data, ggplot2::aes(date, temp_c)) +
  ggplot2::geom_line(colour = "#4C78A8", linewidth = 0.35) +
  ggplot2::geom_hline(yintercept = 26, colour = "#C44E52", linetype = "dashed") +
  ggplot2::labs(title = "Synthetic Tanzania daily temperature, 1990-1991",
                x = "Date", y = "Daily mean temperature (degrees C)") +
  ggplot2::theme_classic(base_size = 11)
grDevices::png(file.path(output_dir, "historical_temperature_example.png"),
               width = 1530, height = 720, res = 180)
print(p)
grDevices::dev.off()

