# Tanzania child-mortality demo: 01 of 05
#
# Purpose: create fully synthetic under-five death records and the historical
# national mortality inputs required by the manuscript workflow. No real
# INDEPTH or other restricted data are used. Run scripts 01--05 in order.
#
# The simulated surveillance deaths have a significant U-shaped distributed
# temperature association. Eighty per cent of recorded death dates are assigned
# to the 15th day of their month to reproduce artificial mid-month date heaping.

# Current demo location. Change this one line only if you move the folder.
project_path <- "."
setwd(project_path)
project_dir <- "."
raw_dir <- file.path(project_dir, "data_raw")
processed_dir <- file.path(project_dir, "data_processed")
output_dir <- file.path(project_dir, "outputs")
dir.create(raw_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(processed_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)

# Historical temperature generator. Script 02 uses the same function and seed,
# so the exposure used to simulate deaths is exactly the model input.
simulate_historical_temperature <- function(dates) {
  set.seed(14062026)
  day_of_year <- as.integer(format(dates, "%j"))
  year_index <- as.integer(format(dates, "%Y")) - min(as.integer(format(dates, "%Y")))
  25.5 +
    3.6 * sin(2 * pi * (day_of_year - 35) / 365.25) +
    0.035 * year_index +
    rnorm(length(dates), mean = 0, sd = 1.25)
}

set.seed(14062028)
dates <- seq.Date(as.Date("1990-01-01"), as.Date("2018-12-31"), by = "day")
years <- as.integer(format(dates, "%Y"))
year_index <- years - 1990
temperature <- simulate_historical_temperature(dates)

# Simulate a distributed U-shaped temperature--mortality association. Effects
# are generated over lags 0--7 and estimated over lags 0--30 in script 03.
instant_log_rr <-
  0.0300 * pmax(temperature - 25.5, 0)^2 +
  0.0250 * pmax(25.0 - temperature, 0)^2
instant_log_rr <- pmin(instant_log_rr, 1.2)
lag_days <- 0:7
lag_weights <- exp(-lag_days / 2.5)
lag_weights <- lag_weights / sum(lag_weights)
distributed_log_rr <- vapply(seq_along(dates), function(i) {
  source_rows <- pmax(1L, i - lag_days)
  sum(instant_log_rr[source_rows] * lag_weights)
}, numeric(1))
daily_true_rr <- exp(distributed_log_rr)

# Synthetic surveillance-site deaths used only to estimate the exposure--
# response curve. Their baseline declines gradually over calendar time.
baseline_log_mean <- log(5.2) - 0.012 * year_index +
  0.04 * cos(2 * pi * as.integer(format(dates, "%j")) / 365.25)
expected_deaths <- exp(baseline_log_mean + distributed_log_rr)
daily_true_deaths <- rpois(length(dates), lambda = expected_deaths)

# One row represents one synthetic child death. The true date is included only
# to document the data-generating mechanism; it is not used in script 03.
true_death_date <- rep(dates, daily_true_deaths)
n_deaths <- length(true_death_date)
age_days <- sample.int(5 * 365, size = n_deaths, replace = TRUE)
date_of_birth <- true_death_date - age_days
is_neonatal <- age_days < 28

is_heaped <- runif(n_deaths) < 0.80
recorded_death_date <- true_death_date
recorded_death_date[is_heaped] <- as.Date(format(true_death_date[is_heaped], "%Y-%m-15"))

raw_deaths <- data.frame(
  record_id = sprintf("TZ_SIM_%06d", seq_len(n_deaths)),
  site_id = "TZ_DEMO",
  country = "Tanzania",
  date_of_birth = format(date_of_birth, "%Y-%m-%d"),
  true_death_date = format(true_death_date, "%Y-%m-%d"),
  recorded_death_date = format(recorded_death_date, "%Y-%m-%d"),
  age_days = age_days,
  age_group = ifelse(is_neonatal, "neonatal", "post_neonatal_under5"),
  date_heaped_to_mid_month = is_heaped,
  synthetic_data_notice = "SIMULATED DATA ONLY - NOT REAL INDIVIDUAL MORTALITY RECORDS",
  stringsAsFactors = FALSE
)
write.csv(raw_deaths,
          file.path(raw_dir, "tanzania_synthetic_raw_death_records.csv"),
          row.names = FALSE)

observed_daily <- data.frame(date = dates)
recorded_counts <- table(recorded_death_date)
observed_daily$death_count_recorded <- as.integer(recorded_counts[as.character(dates)])
observed_daily$death_count_recorded[is.na(observed_daily$death_count_recorded)] <- 0L
observed_daily$day_of_month <- as.integer(format(observed_daily$date, "%d"))
observed_daily$ymonth <- as.integer(format(observed_daily$date, "%Y%m"))
write.csv(observed_daily,
          file.path(processed_dir, "tanzania_recorded_daily_deaths_with_heaping.csv"),
          row.names = FALSE)

monthly_deaths <- aggregate(death_count_recorded ~ ymonth, data = observed_daily, FUN = sum)
names(monthly_deaths)[2] <- "death"
write.csv(monthly_deaths,
          file.path(processed_dir, "tanzania_monthly_deaths_for_aggregate_model.csv"),
          row.names = FALSE)

# One transparent random redistribution is saved for the annual weighting used
# in script 05. Script 03 itself retains monthly counts as its model response.
set.seed(14062029)
redistributed_list <- lapply(monthly_deaths$ymonth, function(this_month) {
  month_dates <- dates[as.integer(format(dates, "%Y%m")) == this_month]
  n_month_deaths <- monthly_deaths$death[monthly_deaths$ymonth == this_month]
  data.frame(
    date = month_dates,
    ymonth = this_month,
    death_count_randomly_redistributed = as.vector(rmultinom(
      n = 1L, size = n_month_deaths,
      prob = rep(1 / length(month_dates), length(month_dates))
    ))
  )
})
redistributed_daily <- do.call(rbind, redistributed_list)
write.csv(redistributed_daily,
          file.path(processed_dir, "tanzania_daily_deaths_random_redistribution_example.csv"),
          row.names = FALSE)

# Create a synthetic national historical series analogous to the total national
# U5MR and demographic inputs used in the manuscript. The latent non-temperature
# component is used only to generate total U5MR; it is deliberately not written
# to disk. Script 05 must recover it from total U5MR and estimated temperature PAFs.
daily_generation <- data.frame(
  year = years,
  temperature_c = temperature,
  expected_deaths = expected_deaths,
  rr = daily_true_rr
)
daily_generation$pdd <- ave(
  daily_generation$expected_deaths,
  daily_generation$year,
  FUN = function(x) x / sum(x)
)
daily_generation$paf <- (daily_generation$rr - 1) / daily_generation$rr
daily_generation$weighted_paf <- daily_generation$paf * daily_generation$pdd
annual_true_paf <- aggregate(weighted_paf ~ year, data = daily_generation, FUN = sum)

historical_years <- 1990:2018
historical_index <- historical_years - 1990
population_total <- 25.4e6 * exp(0.029 * historical_index)
crude_birth_rate <- 49.0 * exp(-0.006 * historical_index)
live_births <- population_total * crude_birth_rate / 1000
latent_temperature_unrelated_u5mr <- 82 * exp(-0.027 * historical_index)
total_u5mr <- latent_temperature_unrelated_u5mr /
  pmax(1 - annual_true_paf$weighted_paf[match(historical_years, annual_true_paf$year)], 0.50)

historical_total_mortality <- data.frame(
  country = "Tanzania",
  year = historical_years,
  population_total = round(population_total),
  crude_birth_rate_per_1000 = round(crude_birth_rate, 3),
  live_births = round(live_births),
  total_u5mr_per_1000 = round(total_u5mr, 3),
  data_source = "Fully synthetic national historical inputs for demonstration",
  stringsAsFactors = FALSE
)
write.csv(historical_total_mortality,
          file.path(processed_dir, "tanzania_historical_total_u5mr_demography.csv"),
          row.names = FALSE)

# The manuscript uses 2019 total mortality as the fixed baseline for future
# heat- and cold-related mortality. Here it is predicted from the synthetic
# historical national series to mimic an externally supplied 2019 estimate.
historical_trend <- lm(log(total_u5mr_per_1000) ~ year, data = historical_total_mortality)
baseline_2019 <- data.frame(
  country = "Tanzania",
  year = 2019L,
  total_u5mr_per_1000 = round(exp(predict(historical_trend,
                                         newdata = data.frame(year = 2019L))), 3),
  data_source = "Synthetic 2019 total U5MR baseline predicted from historical inputs",
  stringsAsFactors = FALSE
)
write.csv(baseline_2019,
          file.path(processed_dir, "tanzania_total_u5mr_baseline_2019.csv"),
          row.names = FALSE)

# Date-heaping diagnostic and plot.
day_summary <- aggregate(death_count_recorded ~ day_of_month, data = observed_daily, FUN = sum)
mid_month_share <- with(observed_daily,
                        sum(death_count_recorded[day_of_month == 15]) / sum(death_count_recorded))
heaping_summary <- data.frame(
  site_id = "TZ_DEMO",
  study_period = "1990-01-01 to 2018-12-31",
  total_synthetic_deaths = n_deaths,
  recorded_mid_month_share = mid_month_share,
  expected_share_without_heaping = 1 / 30.44,
  stringsAsFactors = FALSE
)
write.csv(heaping_summary,
          file.path(output_dir, "date_heaping_summary.csv"),
          row.names = FALSE)

day_summary$mid_month <- day_summary$day_of_month == 15
p <- ggplot2::ggplot(day_summary,
                     ggplot2::aes(day_of_month, death_count_recorded,
                                  fill = mid_month)) +
  ggplot2::geom_col() +
  ggplot2::scale_fill_manual(values = c("FALSE" = "#4C78A8", "TRUE" = "#C44E52"),
                             guide = "none") +
  ggplot2::scale_x_continuous(breaks = 1:31) +
  ggplot2::labs(title = "Synthetic Tanzania data: artificial mid-month clustering",
                x = "Recorded day of month", y = "Number of recorded deaths") +
  ggplot2::theme_classic(base_size = 11)
grDevices::png(file.path(output_dir, "date_heaping_diagnostic.png"),
               width = 1530, height = 900, res = 180)
print(p)
grDevices::dev.off()
